﻿public class OrderTimeout
{
}