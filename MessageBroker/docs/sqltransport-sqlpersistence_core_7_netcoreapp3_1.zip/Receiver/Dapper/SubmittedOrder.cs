namespace Dapper
{
    #region SubmittedOrderDapper

    public class SubmittedOrder
    {
        public string Id { get; set; }
        public int Value { get; set; }
    }

    #endregion
}