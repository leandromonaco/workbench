﻿using System.Threading.Tasks;

public interface ICalculateStuff
{
    Task Calculate(int number);
}
